<?php
require("json.php");
displayTable("professors");
?>