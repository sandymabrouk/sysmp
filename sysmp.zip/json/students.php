<?php
require("json.php");
displayTable("students");
?>