<?php
require("json.php");
displayTable("degrees");
?>